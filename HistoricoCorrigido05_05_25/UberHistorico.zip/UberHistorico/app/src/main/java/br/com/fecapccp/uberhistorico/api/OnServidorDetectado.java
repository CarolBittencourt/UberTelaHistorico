package br.com.fecapccp.uberhistorico.api;

public interface OnServidorDetectado {
    void onDetectado();
}